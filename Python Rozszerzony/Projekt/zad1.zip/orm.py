from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Enum, ForeignKey, update
from sqlalchemy.orm import declarative_base, sessionmaker, validates, relationship, mapped_column, Mapped
from datetime import datetime
import enum
from typing import List
import argparse



class LendingStates(enum.Enum):
    LENT = "lent"
    ON_SHELF = "on_shelf"
    LOST = "lost"


# wyznaczamy styl kodu
Base = declarative_base()


# jedna książka może mieć wiele wypożyczeń, releacja jeden do wielu
class Lending(Base):
    # SCHEMA
    __tablename__ = 'lendings'

    id = Column(Integer, primary_key=True, autoincrement=True)
    friend_id = mapped_column(Integer, ForeignKey('Friends.id'), nullable=False)
    friend = relationship("Friend", back_populates="lending")

    lend_date = mapped_column(DateTime, nullable=False)
    return_date = mapped_column(DateTime, nullable=True)

    book_id = mapped_column(Integer, ForeignKey('books.id'))

    # VALIDATIONS
    @validates('return_date')
    def validate_return_date(self, key, return_date):
        if return_date and return_date > datetime.now():
            raise ValueError("Lending should be before Returning!")
        return return_date


class Book(Base):
    # SCHEMA
    __tablename__ = 'books'
    id = mapped_column(Integer, primary_key=True, autoincrement=True, nullable=False)
    author = mapped_column(String(20), nullable=False)
    title = mapped_column(String(30), nullable=False)
    year = mapped_column(Integer, nullable=False)
    genre = mapped_column(String(20), nullable=False)

    # chcemy żeby były przetrzymywane nazwy zdefiniowane stringiem
    lend_state = Column(Enum(LendingStates, values_callable=lambda x: [str(member.value) for member in LendingStates]),
                        default='on_shelf')

    # VALIDATIONS
    @validates('year')
    def validate_year(self, key, year):
        if year > datetime.now().year:
            raise ValueError("Book cannot be published in the future!")
        return year

    def __str__(self):
        return


class Friend(Base):
    # SCHEMA
    __tablename__ = 'Friends'
    id = mapped_column(Integer, primary_key=True, autoincrement=True)
    name = mapped_column(String(20), nullable=False)
    surname = mapped_column(String(30), nullable=False)
    email = mapped_column(String(30), nullable=False)

    # pierwszy argument to kto stoi po drugiej stronie relacji, drugi to gdzie relacja jest 'zaczepiona'
    lending: Mapped[List[Lending]] = relationship("Lending", back_populates="friend")

    # VALIDATIONS
    @validates('email')
    def validate_email(self, key, email):
        if '@' not in email:
            raise ValueError("Email should contain '@'!")
        return email


engine = create_engine('sqlite:///library.db')
Base.metadata.create_all(bind=engine)

Session = sessionmaker(bind=engine)
session = Session()


def add_book(author, title, year, genre):
    book = Book(author=author, title=title, year=year, genre=genre)
    session.add(book)
    session.commit()


def add_Friend(name, surname, email):
    friend = Friend(name=name, surname=surname, email=email)
    session.add(friend)
    session.commit()


def borrow_book(friend_id, title=''):
    # znajdź możliwą do wypożyczenia książkę z danym tytułem
    book = session.query(Book).filter(Book.title == title, Book.lend_state == 'on_shelf').first()
    friend = session.query(Friend).filter(Friend.id == friend_id).first()
    if book:
        new_lending = Lending(friend_id=friend_id, lend_date=datetime.now(), book_id=book.id)
        session.add(new_lending)
        friend.lending.append(new_lending)  # dodanie wypożyczenia do książki
        book.lend_state = 'lent'
        session.commit()
        return
    raise ValueError("Book unavailable!")


def return_book(friend_id, title):
    # pobieramy wszystkie książki o danym tytule i wypożyczone
    books_ids = [book.id for book in session.query(Book).filter(Book.title == title, Book.lend_state == 'lent').all()]
    friend = session.query(Friend).filter(Friend.id == friend_id).first()

    for lending in friend.lending:
        # szukamy wypożyczenia zrobionego przez znajomego, aktualizujemy je
        if lending.book_id in books_ids:
            lending.return_date = datetime.now()
            # zmieniamy też stan książki
            book = session.query(Book).filter(Book.id == lending.book_id).first()
            book.lend_state = 'on_shelf'
            session.commit()


def show_all_books(books=session.query(Book).all()):
    for book in books:
        print(f"ID: {book.id}, title: {book.title}, lend_state: {book.lend_state}, authors: {book.author}")


def show_all_friends():
    friends = session.query(Friend).all()
    for f in friends:
        print(f"ID: {f.id}, name: {f.name}, surname: {f.surname}, email: {f.email}")


def show_all_lent():
    books = session.query(Book).filter(Book.lend_state == 'lent').all()
    show_all_books(books)


def show_all_lendings():
    lendings = session.query(Lending).all()
    for l in lendings:
        print(
            f"ID: {l.id} friend name: {l.friend.name}, lend_date: {l.lend_date}, return_date: {l.return_date}, book_id: {l.book_id}")

def main():
    parser = argparse.ArgumentParser(description="Library Management System")

    # Subparsers for different functions
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # add_book command
    add_book_parser = subparsers.add_parser("add_book")
    add_book_parser.add_argument("--author", required=True)
    add_book_parser.add_argument("--title", required=True)
    add_book_parser.add_argument("--year", type=int, required=True)
    add_book_parser.add_argument("--genre", required=True)

    # add_friend command
    add_friend_parser = subparsers.add_parser("add_friend")
    add_friend_parser.add_argument("--name", required=True)
    add_friend_parser.add_argument("--surname", required=True)
    add_friend_parser.add_argument("--email", required=True)

    # borrow_book command
    borrow_book_parser = subparsers.add_parser("borrow_book")
    borrow_book_parser.add_argument("--friend_id", type=int, required=True)
    borrow_book_parser.add_argument("--title", default="")

    # return_book command
    return_book_parser = subparsers.add_parser("return_book")
    return_book_parser.add_argument("--friend_id", type=int, required=True)
    return_book_parser.add_argument("--title", required=True)

    # show_all_books command
    subparsers.add_parser("show_all_books")

    # show_all_friends command
    subparsers.add_parser("show_all_friends")

    # show_all_lent command
    subparsers.add_parser("show_all_lent")

    # show_all_lendings command
    subparsers.add_parser("show_all_lendings")

    args = parser.parse_args()

    # Call the appropriate function based on the parsed arguments
    if args.command == "add_book":
        add_book(args.author, args.title, args.year, args.genre)
    elif args.command == "add_friend":
        add_Friend(args.name, args.surname, args.email)
    elif args.command == "borrow_book":
        borrow_book(args.friend_id, args.title)
    elif args.command == "return_book":
        return_book(args.friend_id, args.title)
    elif args.command == "show_all_books":
        show_all_books()
    elif args.command == "show_all_friends":
        show_all_friends()
    elif args.command == "show_all_lent":
        show_all_lent()
    elif args.command == "show_all_lendings":
        show_all_lendings()

if __name__ == "__main__":
    main()


# python3 orm.py add_book --author "Author Name" --title "Book Title" --year 2022 --genre "Fiction"
# python3 orm.py show_all_books
# python3 orm.py add_friend --name "Phili" --surname "Smith" --email "mail@gmail.com"
# python3 orm.py show_all_friends
# python3 orm.py borrow_book --friend_id 1 --title "Book Title"
# python3 orm.py show_all_lendings
# python3 orm.py show_all_lent
# python3 orm.py return_book --friend_id 1 --title "Book Title"