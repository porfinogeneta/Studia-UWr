# PEP8
- użyłem pep8
- polecenie - pep8 plik.py

# wykonane zadania
- tylko pierwsze 2