
export default function DeleteNotification() {

    return (
            <div className="rounded bg-red-600 text-white px-4 py-2 absolute bottom-4 left-4 transform transition-all duration-500 ease-in-out">
                Element deleted
            </div>
        )
}